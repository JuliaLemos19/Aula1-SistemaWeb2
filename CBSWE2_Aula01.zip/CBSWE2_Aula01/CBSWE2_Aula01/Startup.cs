﻿using CBSWE2_Aula01.Repositorio;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.AspNetCore.Hosting.Internal.HostingApplication;

namespace CBSWE2_Aula01
{
    public class Startup
    {

        public void Configure(IApplicationBuilder app)
        {

            app.Run(Roteamento);
            app.Run(LivrosParaLer);
        }
        public Task LivrosParaLer(HttpContext context)

        {
            var _repo = new LivroRepositorioCSV();
            return context.Response.WriteAsync(_repo.ParaLer.ToString());


        }

            public Task Roteamento(HttpContext context)
       
                {
                    var _repo = new LivroRepositorioCSV();
                    var caminhosAtendidos = new Dictionary<string, string>
            {
                { "/Livros/ParaLer", _repo.Paraler.ToString() },
                { "/Livros/Lendo", _repo.Lendo.ToString() },
                { "/Livros/Lidos", _repo.Lidos.ToString() }
            };

                    if (caminhosAtendidos.ContainsKey(context.Request.Path))
                    {
                        return context.Response
                        .WriteAsync(caminhosAtendidos[context.Request.Path]);
                    }
                    return context.Response.WriteAsync("Caminho inexistente.");
                }
            }
        }
    