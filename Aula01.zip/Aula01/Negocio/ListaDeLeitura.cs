﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula01.Negocio
{
    public class ListaDeLeitura
    {
        private List<Livro> _livro;
        public ListaDeLeitura(string titulo, params Livro[] livros)
        {
            Titulo = titulo;
            _livro = livros.ToList();
            _livros.ForEach(l => l.Lista = this);
        }
        public string Titulo { get; set; }
        public IEnumerable<Livro> Livros
        {
            get { return _livros; }
        }
        public override string ToString()
        {
            {
                var Linhas = new StringBuilder();
                Linhas.AppendLine(Titulo);
                Linhas.AppendLine("=========");
                foreach (var livro in Livros)
                {
                    Linhas.AppendLine(livro.ToString());
                }
                return Linhas.ToString();
            }
        }
    }
}
